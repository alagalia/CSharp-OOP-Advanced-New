﻿namespace _09.TrafficLights
{
    public enum LightColor
    {
       Red,
       Green,
       Yellow
    }
}