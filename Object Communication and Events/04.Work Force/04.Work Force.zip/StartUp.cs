﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04.Work_Force
{
    using _04.Work_Force.Models;
    using _04.Work_Force.Repositories;

    public class StartUp
    {
        public static void Main()
        {
            var jobs = new JobRepository();
            var employees = new EmployeeRepository();

            var input = Console.ReadLine()
                .Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            while (!input[0].Equals("End"))
            {
                switch (input[0])
                {
                    case "Job":
                        {
                            var jobName = input[1];
                            var jobHoursRequired = int.Parse(input[2]);
                            var employee = employees.GetEmployee(input[3]);

                            var job = new Job(jobName, jobHoursRequired, employee);
                            job.JobDone += jobs.FinishedJob;
                            jobs.AddJob(job);
                        }

                        break;
                    case "StandartEmployee":
                        {
                            var employeeName = input[1];
                            var employee = new StandartEmployee(employeeName);
                            employees.AddEmployee(employee);
                        }

                        break;
                    case "PartTimeEmployee":
                        {
                            var employeeName = input[1];
                            var employee = new PartTimeEmployee(employeeName);
                            employees.AddEmployee(employee);
                        }

                        break;
                    case "Pass":
                        jobs.Update();
                        break;
                    case "Status":
                        jobs.Status();
                        break;
                }

                input = Console.ReadLine()
                    .Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            }
        }
    }
}
