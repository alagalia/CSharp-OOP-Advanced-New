﻿namespace _04.Work_Force.Interfaces
{
    public interface IEmployee
    {
        string Name { get; set; }

        int Hours { get; set; }
    }
}